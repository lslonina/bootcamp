package pl.coderslab.controller;

import pl.coderslab.dao.AdminDao;
import pl.coderslab.model.Admin;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/login")
public class Login extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html; charset=UTF-8");
        Admin admin = new Admin();
        admin.setEmail(request.getParameter("email"));
        admin.setPassword(request.getParameter("password"));

        AdminDao.authorization(admin);

        if (admin.isAdminLogged()) {
            HttpSession session = request.getSession(true);
            session.setAttribute("users", admin.getId());
            response.sendRedirect("/");
        } else {
            request.setAttribute("warning2", "true");
            doGet(request, response);
        }


    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        getServletContext().getRequestDispatcher("/login.jsp").forward(request, response);
    }
}
